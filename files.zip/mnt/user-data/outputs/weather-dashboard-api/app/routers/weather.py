from typing import List, Literal, Optional

from fastapi import APIRouter, HTTPException, Query

from app.models.weather import CurrentWeatherResponse, ForecastResponse, GeoResult
from app.services import weather_service

router = APIRouter()

UnitsType = Literal["metric", "imperial", "standard"]


@router.get(
    "/search",
    response_model=List[GeoResult],
    summary="Search for cities",
    description="Returns up to 5 matching locations for a city name query.",
)
async def search_city(
    q: str = Query(..., min_length=2, description="City name to search"),
):
    try:
        results = await weather_service.geocode(q)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Geocoding failed: {str(e)}")

    if not results:
        raise HTTPException(status_code=404, detail=f"No cities found for '{q}'")

    return results


@router.get(
    "/current",
    response_model=CurrentWeatherResponse,
    summary="Get current weather",
    description="Get current weather by city name or coordinates.",
)
async def current_weather(
    city: Optional[str] = Query(None, description="City name (e.g. London)"),
    lat: Optional[float] = Query(None, description="Latitude"),
    lon: Optional[float] = Query(None, description="Longitude"),
    units: UnitsType = Query("metric", description="Units: metric | imperial | standard"),
):
    lat, lon = await _resolve_coords(city, lat, lon)
    try:
        return await weather_service.get_current_weather(lat, lon, units)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Weather fetch failed: {str(e)}")


@router.get(
    "/forecast",
    response_model=ForecastResponse,
    summary="Get 5-day forecast",
    description="Get 5-day / 3-hour forecast by city name or coordinates.",
)
async def forecast(
    city: Optional[str] = Query(None, description="City name (e.g. Mumbai)"),
    lat: Optional[float] = Query(None, description="Latitude"),
    lon: Optional[float] = Query(None, description="Longitude"),
    units: UnitsType = Query("metric", description="Units: metric | imperial | standard"),
):
    lat, lon = await _resolve_coords(city, lat, lon)
    try:
        return await weather_service.get_forecast(lat, lon, units)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Forecast fetch failed: {str(e)}")


async def _resolve_coords(
    city: Optional[str],
    lat: Optional[float],
    lon: Optional[float],
) -> tuple[float, float]:
    """Resolve city name or lat/lon to coordinates."""
    if lat is not None and lon is not None:
        return lat, lon

    if city:
        results = await weather_service.geocode(city)
        if not results:
            raise HTTPException(status_code=404, detail=f"City '{city}' not found")
        return results[0].lat, results[0].lon

    raise HTTPException(
        status_code=400,
        detail="Provide either 'city' or both 'lat' and 'lon' query params.",
    )
